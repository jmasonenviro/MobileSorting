import { useEffect, useRef, useState } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import {
  barcodeImageSrc,
  createProduct,
  getMeta,
  getProduct,
  lookupBarcode,
  updateProduct,
} from '../api/client.js';

const emptyForm = {
  name: '',
  manufacturer: '',
  category: '',
  internalId: '',
  barcode: '',
  unitOfMeasure: '',
  notes: '',
};

export default function AddEditProduct({ mode }) {
  const { id } = useParams();
  const location = useLocation();
  const navigate = useNavigate();

  const [meta, setMeta] = useState({ categories: [], idHints: {}, categoriesRequiringManualId: [] });
  const [form, setForm] = useState(emptyForm);
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [lookupNote, setLookupNote] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const fileInputRef = useRef(null);
  const touchedRef = useRef(new Set());

  // Load category metadata (list + tier-aware ID hints) up front.
  useEffect(() => {
    getMeta().then(setMeta).catch(() => {});
  }, []);

  // Create mode: seed from the barcode/photo the Scan screen already
  // captured, then attempt a best-effort external lookup. Never overwrite
  // anything the user has already typed.
  useEffect(() => {
    if (mode !== 'create') return;
    const state = location.state || {};
    if (state.barcode) {
      setForm((f) => ({ ...f, barcode: state.barcode }));
    }
    if (state.imageFile) {
      setImageFile(state.imageFile);
      setImagePreview(URL.createObjectURL(state.imageFile));
    }

    // Category was already picked on the Scan screen (that's also where
    // the "where's the ID tag" hint was shown, before the photo was taken)
    // — carry it over so it isn't asked twice.
    if (state.category) {
      setForm((f) => ({ ...f, category: state.category }));
    }

    // Came from typing a Renova ID tag number on the Scan screen that
    // didn't match anything in the catalog yet — carry the ID over so
    // it's saved once here and auto-fills for everyone next time.
    if (state.internalId) {
      setForm((f) => ({ ...f, internalId: state.internalId }));
      setLookupNote(
        "This Renova ID isn't in the catalog yet — fill in the rest and save it once. " +
          'Next time anyone enters this same ID, these details will fill in automatically.'
      );
    }

    if (state.barcode) {
      setLookupNote('Checking manufacturer databases for this barcode… (optional, may find nothing)');
      lookupBarcode(state.barcode)
        .then((result) => {
          const { prefill } = result;
          setForm((f) => ({
            ...f,
            manufacturer: !touchedRef.current.has('manufacturer') && prefill.manufacturer ? prefill.manufacturer : f.manufacturer,
            name: !touchedRef.current.has('name') && (prefill.name || prefill.brand) ? prefill.name || prefill.brand : f.name,
          }));
          const hit = prefill.manufacturer || prefill.name || prefill.brand;
          setLookupNote(
            hit
              ? 'Found some details automatically — please double-check them.'
              : "No match found in outside databases (common for construction tools) — that's expected, just fill in what you know."
          );
        })
        .catch(() => {
          setLookupNote('Lookup failed — no problem, just fill in what you know.');
        });
    }

    // No barcode in the photo — came from reading a printed ID tag/nameplate
    // instead (OCR). Pre-fill from whatever it found, but make clear this
    // needs a human check: OCR on a scratched/worn/angled tag is often wrong.
    if (state.ocrFields) {
      const { model, serialNumber, manufacturer, rawText } = state.ocrFields;
      setForm((f) => ({
        ...f,
        name: !touchedRef.current.has('name') && model ? model : f.name,
        manufacturer: !touchedRef.current.has('manufacturer') && manufacturer ? manufacturer : f.manufacturer,
        internalId: !touchedRef.current.has('internalId') && serialNumber ? serialNumber : f.internalId,
        notes:
          !touchedRef.current.has('notes') && rawText
            ? `Text read from tag photo (unverified):\n${rawText}`
            : f.notes,
      }));
      setLookupNote(
        "Read this from the tag's photo — OCR isn't perfect, especially on worn or angled tags, so please check every field before saving."
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode]);

  // Edit mode: load the existing product.
  useEffect(() => {
    if (mode !== 'edit') return;
    getProduct(id).then((p) => {
      setForm({
        name: p.name || '',
        manufacturer: p.manufacturer || '',
        category: p.category || '',
        internalId: p.internalId || '',
        barcode: p.barcode || '',
        unitOfMeasure: p.unitOfMeasure || '',
        notes: p.notes || '',
      });
      setImagePreview(barcodeImageSrc(p));
    });
  }, [mode, id]);

  function set(field, value) {
    touchedRef.current.add(field);
    setForm((f) => ({ ...f, [field]: value }));
  }

  function handleImagePick(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
  }

  const requiresManualId = meta.categoriesRequiringManualId.includes(form.category);
  const idHint = meta.idHints[form.category];

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');

    if (!form.name.trim()) {
      setError('Tool name is required.');
      return;
    }
    if (requiresManualId && !form.manufacturer.trim()) {
      setError(`"${form.category}" has no factory ID tag — Manufacturer is required too.`);
      return;
    }

    setSaving(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => fd.append(k, v ?? ''));
      if (imageFile) fd.append('barcodeImage', imageFile);

      const product =
        mode === 'create' ? await createProduct(fd) : await updateProduct(id, fd);
      navigate(`/products/${product.id}`);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <h2>{mode === 'create' ? 'Add Product' : 'Edit Product'}</h2>

      {lookupNote && mode === 'create' && <p className="hint">{lookupNote}</p>}
      {error && <div className="error-box">{error}</div>}

      <form onSubmit={handleSubmit}>
        <label>Category</label>
        <select value={form.category} onChange={(e) => set('category', e.target.value)}>
          <option value="">Select a category…</option>
          {meta.categories.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
        {idHint && <div className="hint-box">{idHint}</div>}

        <label>Tool Name{requiresManualId ? ' (required)' : ''}</label>
        <input type="text" value={form.name} onChange={(e) => set('name', e.target.value)} />

        <label>Manufacturer{requiresManualId ? ' (required)' : ''}</label>
        <input
          type="text"
          value={form.manufacturer}
          onChange={(e) => set('manufacturer', e.target.value)}
        />

        <label>Barcode</label>
        <input type="text" value={form.barcode} onChange={(e) => set('barcode', e.target.value)} />

        <label>Internal ID</label>
        <input
          type="text"
          value={form.internalId}
          onChange={(e) => set('internalId', e.target.value)}
        />

        <label>Unit of Measure</label>
        <input
          type="text"
          placeholder="each, box, roll…"
          value={form.unitOfMeasure}
          onChange={(e) => set('unitOfMeasure', e.target.value)}
        />

        <label>Notes</label>
        <textarea value={form.notes} onChange={(e) => set('notes', e.target.value)} />

        <label>Barcode Photo</label>
        {imagePreview && <img src={imagePreview} alt="Barcode" className="upload-preview" />}
        <button type="button" className="btn btn-outline" onClick={() => fileInputRef.current?.click()}>
          {imagePreview ? 'Replace photo' : 'Attach photo'}
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          style={{ display: 'none' }}
          onChange={handleImagePick}
        />

        <button type="submit" className="btn btn-primary" disabled={saving} style={{ marginTop: 16 }}>
          {saving ? 'Saving…' : 'Save Product'}
        </button>
      </form>
    </div>
  );
}
