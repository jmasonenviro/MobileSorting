import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createPurchase } from '../api/client.js';

export default function AddPurchase() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [vendor, setVendor] = useState('');
  const [purchaseDate, setPurchaseDate] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [unitCost, setUnitCost] = useState('');
  const [poNumber, setPoNumber] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  async function submit(e) {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      await createPurchase({
        productId: Number(id),
        vendor,
        purchaseDate,
        quantity: Number(quantity),
        unitCost: Number(unitCost) || 0,
        poNumber,
        notes,
      });
      navigate(`/products/${id}`);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <h2>Add Purchase</h2>
      {error && <div className="error-box">{error}</div>}
      <form onSubmit={submit}>
        <label>Vendor</label>
        <input type="text" value={vendor} onChange={(e) => setVendor(e.target.value)} />

        <label>Purchase Date</label>
        <input type="date" value={purchaseDate} onChange={(e) => setPurchaseDate(e.target.value)} />

        <label>Quantity</label>
        <input
          type="number"
          min="1"
          value={quantity}
          onChange={(e) => setQuantity(e.target.value)}
          required
        />

        <label>Unit Cost</label>
        <input
          type="number"
          step="0.01"
          min="0"
          value={unitCost}
          onChange={(e) => setUnitCost(e.target.value)}
        />

        <label>PO Number</label>
        <input type="text" value={poNumber} onChange={(e) => setPoNumber(e.target.value)} />

        <label>Notes</label>
        <textarea value={notes} onChange={(e) => setNotes(e.target.value)} />

        <button type="submit" className="btn btn-primary" disabled={saving} style={{ marginTop: 16 }}>
          {saving ? 'Saving…' : 'Save Purchase'}
        </button>
      </form>
    </div>
  );
}
