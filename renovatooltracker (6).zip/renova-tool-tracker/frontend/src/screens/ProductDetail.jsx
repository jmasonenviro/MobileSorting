import { useCallback, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { barcodeImageSrc, checkIn, checkOut, getProduct } from '../api/client.js';
import Modal from '../components/Modal.jsx';
import {
  closedCheckoutStatus,
  groupByBatch,
  inferBatches,
  openCheckoutStatus,
} from '../lib/checkoutMath.js';

function fmtDate(d) {
  return new Date(d).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
}

export default function ProductDetail() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [error, setError] = useState('');
  const [panel, setPanel] = useState(null); // null | 'checkout' | 'checkin'
  const [modal, setModal] = useState(null); // null | 'onhand' | 'checkedout' | 'timesout'

  const load = useCallback(() => {
    getProduct(id)
      .then(setProduct)
      .catch((err) => setError(err.message));
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  if (error) return <div className="error-box">{error}</div>;
  if (!product) return <p className="hint">Loading…</p>;

  const imgSrc = barcodeImageSrc(product);

  return (
    <div>
      <h2>{product.name}</h2>
      <p className="hint">
        {product.manufacturer || 'Unknown manufacturer'} · {product.category || 'Uncategorized'}
        {product.internalId ? ` · ID ${product.internalId}` : ''}
      </p>

      {imgSrc && <img src={imgSrc} alt="Barcode" className="upload-preview" />}

      <div className="stat-row">
        <button className="stat stat-clickable" onClick={() => setModal('onhand')}>
          <div className="value">{product.onHand}</div>
          <div className="label">On Hand</div>
          <div className="tap-hint">Tap for details</div>
        </button>
        <button className="stat stat-clickable" onClick={() => setModal('checkedout')}>
          <div className="value">{product.currentlyCheckedOut}</div>
          <div className="label">Checked Out</div>
          <div className="tap-hint">Tap for details</div>
        </button>
        <button className="stat stat-clickable" onClick={() => setModal('timesout')}>
          <div className="value">{product.timesOut ?? 0}</div>
          <div className="label">Times Out</div>
          <div className="tap-hint">Tap for details</div>
        </button>
      </div>

      {product.openCheckouts?.length > 0 && (
        <div className="card">
          <strong>Currently checked out to:</strong>
          {product.openCheckouts.map((c) => {
            const status = openCheckoutStatus(c);
            return (
              <div key={c.id} className="history-entry">
                {c.outstanding} × {c.person} — {c.jobSite || 'no site given'}
                <div>
                  <span className={`duration-pill duration-${status.level}`}>{status.label}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {modal === 'onhand' && <OnHandModal product={product} onClose={() => setModal(null)} />}
      {modal === 'checkedout' && <CheckedOutModal product={product} onClose={() => setModal(null)} />}
      {modal === 'timesout' && <TimesOutModal product={product} onClose={() => setModal(null)} />}

      <div className="btn-row" style={{ marginBottom: 16 }}>
        <button className="btn btn-primary" onClick={() => setPanel(panel === 'checkout' ? null : 'checkout')}>
          Check Out
        </button>
        <button
          className="btn btn-accent"
          disabled={!product.openCheckouts?.length}
          onClick={() => setPanel(panel === 'checkin' ? null : 'checkin')}
        >
          Check In
        </button>
      </div>

      {panel === 'checkout' && (
        <CheckOutForm
          productId={product.id}
          onDone={() => {
            setPanel(null);
            load();
          }}
        />
      )}
      {panel === 'checkin' && (
        <CheckInForm
          productId={product.id}
          openCheckouts={product.openCheckouts}
          onDone={() => {
            setPanel(null);
            load();
          }}
        />
      )}

      <Link to={`/products/${product.id}/purchases/new`} className="btn btn-outline">
        Add Purchase
      </Link>
      <Link to={`/products/${product.id}/edit`} className="btn btn-outline">
        Edit Product
      </Link>

      <h3>Purchase History</h3>
      {product.purchases.length === 0 && <p className="hint">No purchases recorded yet.</p>}
      {product.purchases.map((p) => (
        <div key={p.id} className="history-entry">
          {p.purchaseDate || 'no date'} — {p.quantity} × ${p.unitCost} from {p.vendor || 'unknown vendor'}
          {p.poNumber ? ` (PO ${p.poNumber})` : ''}
        </div>
      ))}

      <h3>Use History</h3>
      {product.transactions.length === 0 && <p className="hint">No check-outs or check-ins yet.</p>}
      {product.transactions
        .slice()
        .reverse()
        .map((t) =>
          t.type === 'Check-Out' ? (
            <div key={t.id} className="history-entry">
              Checked out: {t.quantity} to {t.person} at {t.jobSite || 'unspecified site'} on{' '}
              {new Date(t.checkOutDateTime).toLocaleString()}
              {(() => {
                const checkin = product.transactions.find(
                  (x) => x.type === 'Check-In' && x.relatedCheckoutId === t.id
                );
                const status = checkin ? closedCheckoutStatus(t, checkin) : openCheckoutStatus(t);
                return (
                  <div>
                    <span className={`duration-pill duration-${status.level}`}>
                      {checkin ? status.label : `Still out · ${status.label}`}
                    </span>
                  </div>
                );
              })()}
            </div>
          ) : (
            <div key={t.id} className="history-entry">
              Checked in: {t.quantityReturned} ({t.condition || 'condition not noted'}) on{' '}
              {new Date(t.checkInDateTime).toLocaleString()}
            </div>
          )
        )}
    </div>
  );
}

function CheckOutForm({ productId, onDone }) {
  const [person, setPerson] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [jobSite, setJobSite] = useState('');
  const [expectedDays, setExpectedDays] = useState(3);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      await checkOut({
        productId,
        person,
        quantity: Number(quantity),
        jobSite,
        expectedDays: Number(expectedDays),
      });
      onDone();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <form className="card" onSubmit={submit}>
      {error && <div className="error-box">{error}</div>}
      <label>Person</label>
      <input type="text" value={person} onChange={(e) => setPerson(e.target.value)} required />
      <label>Quantity</label>
      <input
        type="number"
        min="1"
        value={quantity}
        onChange={(e) => setQuantity(e.target.value)}
        required
      />
      <label>Job / Site</label>
      <input type="text" value={jobSite} onChange={(e) => setJobSite(e.target.value)} />
      <label>How many days do you expect to use this?</label>
      <input
        type="number"
        min="1"
        value={expectedDays}
        onChange={(e) => setExpectedDays(e.target.value)}
        required
      />
      <p className="hint">
        We'll flag this as overdue automatically once this many days have passed without a check-in.
      </p>
      <button type="submit" className="btn btn-primary" disabled={saving} style={{ marginTop: 12 }}>
        {saving ? 'Checking out…' : 'Confirm Check Out'}
      </button>
    </form>
  );
}

function CheckInForm({ productId, openCheckouts, onDone }) {
  const [relatedCheckoutId, setRelatedCheckoutId] = useState(openCheckouts?.[0]?.id || '');
  const [quantityReturned, setQuantityReturned] = useState(openCheckouts?.[0]?.outstanding || 1);
  const [condition, setCondition] = useState('Good');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      await checkIn({
        productId,
        relatedCheckoutId: Number(relatedCheckoutId),
        quantityReturned: Number(quantityReturned),
        condition,
        notes,
      });
      onDone();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <form className="card" onSubmit={submit}>
      {error && <div className="error-box">{error}</div>}
      <label>Returning which check-out?</label>
      <select value={relatedCheckoutId} onChange={(e) => setRelatedCheckoutId(e.target.value)}>
        {openCheckouts.map((c) => (
          <option key={c.id} value={c.id}>
            {c.outstanding} × {c.person} — {c.jobSite || 'no site'}
          </option>
        ))}
      </select>
      <label>Quantity Returned</label>
      <input
        type="number"
        min="1"
        value={quantityReturned}
        onChange={(e) => setQuantityReturned(e.target.value)}
        required
      />
      <label>Condition</label>
      <select value={condition} onChange={(e) => setCondition(e.target.value)}>
        <option>Good</option>
        <option>Fair</option>
        <option>Damaged</option>
        <option>Needs Repair</option>
      </select>
      <label>Notes</label>
      <textarea value={notes} onChange={(e) => setNotes(e.target.value)} />
      <button type="submit" className="btn btn-accent" disabled={saving} style={{ marginTop: 12 }}>
        {saving ? 'Checking in…' : 'Confirm Check In'}
      </button>
    </form>
  );
}

// A note shown wherever batch attribution is inferred rather than tracked
// as fact — there's no unique tag per physical unit today (a product's
// Barcode/Internal ID covers the whole tool type), so "which purchase
// batch" is a best-effort guess (oldest-purchased-first), not certain.
function InferredNote() {
  return (
    <p className="inferred-note">
      "From" is inferred by assuming the oldest-purchased units get used first — this tool doesn't have a
      unique tag per physical unit yet, so it's a best-effort estimate, not a tracked fact.
    </p>
  );
}

function OnHandModal({ product, onClose }) {
  const units = inferBatches({ purchases: product.purchases, transactions: product.transactions });
  const onHandBatches = groupByBatch(units.filter((u) => u.status === 'available'));

  return (
    <Modal title="On Hand — by purchase batch" onClose={onClose}>
      <div className="table-summary">
        <div className="stat">
          <div className="value">{product.totalPurchased}</div>
          <div className="label">Purchased</div>
        </div>
        <div className="stat">
          <div className="value">{product.currentlyCheckedOut}</div>
          <div className="label">Out</div>
        </div>
        <div className="stat">
          <div className="value">{product.onHand}</div>
          <div className="label">On Hand</div>
        </div>
      </div>
      <table className="mock-table">
        <thead>
          <tr>
            <th>Qty</th>
            <th>Purchased From</th>
            <th>Unit Cost</th>
          </tr>
        </thead>
        <tbody>
          {onHandBatches.length ? (
            onHandBatches.map((b, i) => (
              <tr key={i}>
                <td>{b.count}</td>
                <td>
                  {b.vendor}
                  {b.poNumber ? ` · PO ${b.poNumber}` : ''}
                </td>
                <td>${b.unitCost.toFixed(2)}</td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="3">Nothing on hand right now.</td>
            </tr>
          )}
        </tbody>
      </table>
      <InferredNote />
    </Modal>
  );
}

function CheckedOutModal({ product, onClose }) {
  const units = inferBatches({ purchases: product.purchases, transactions: product.transactions });

  return (
    <Modal title="Checked Out — currently out" onClose={onClose}>
      <table className="mock-table">
        <thead>
          <tr>
            <th>Who / Site</th>
            <th>Qty</th>
            <th>From</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {product.openCheckouts?.length ? (
            product.openCheckouts.map((c) => {
              const status = openCheckoutStatus(c);
              const batches = groupByBatch(
                units.filter((u) => u.status === 'checked-out' && u.assignedCheckoutId === c.id)
              );
              return (
                <tr key={c.id}>
                  <td>
                    {c.person}
                    <br />
                    <span className="hint" style={{ margin: 0 }}>
                      {c.jobSite || 'no site given'}
                    </span>
                  </td>
                  <td>{c.outstanding}</td>
                  <td>
                    {batches
                      .map((b) => `${b.count} × PO ${b.poNumber || '—'} · $${b.unitCost.toFixed(2)}`)
                      .join(', ') || '—'}
                  </td>
                  <td>
                    <span className={`duration-pill duration-${status.level}`}>{status.label}</span>
                  </td>
                </tr>
              );
            })
          ) : (
            <tr>
              <td colSpan="4">Nothing currently checked out.</td>
            </tr>
          )}
        </tbody>
      </table>
      <InferredNote />
    </Modal>
  );
}

function TimesOutModal({ product, onClose }) {
  const checkoutTxs = product.transactions.filter((t) => t.type === 'Check-Out').slice().reverse();

  return (
    <Modal title="Times Out — full history" onClose={onClose}>
      <table className="mock-table">
        <thead>
          <tr>
            <th>Person</th>
            <th>Qty</th>
            <th>Site</th>
            <th>Out</th>
            <th>Back</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {checkoutTxs.length ? (
            checkoutTxs.map((c) => {
              const checkin = product.transactions.find(
                (t) => t.type === 'Check-In' && t.relatedCheckoutId === c.id
              );
              const status = checkin ? closedCheckoutStatus(c, checkin) : openCheckoutStatus(c);
              return (
                <tr key={c.id}>
                  <td>{c.person}</td>
                  <td>{c.quantity}</td>
                  <td>{c.jobSite || 'unspecified'}</td>
                  <td>{fmtDate(c.checkOutDateTime)}</td>
                  <td>{checkin ? fmtDate(checkin.checkInDateTime) : <em>still out</em>}</td>
                  <td>
                    <span className={`duration-pill duration-${status.level}`}>{status.label}</span>
                  </td>
                </tr>
              );
            })
          ) : (
            <tr>
              <td colSpan="6">No check-outs yet.</td>
            </tr>
          )}
        </tbody>
      </table>
      <p className="hint" style={{ marginTop: 10 }}>{checkoutTxs.length} check-out(s) total for this tool.</p>
    </Modal>
  );
}
