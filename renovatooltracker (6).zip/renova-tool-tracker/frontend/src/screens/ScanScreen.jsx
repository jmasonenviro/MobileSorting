import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import BarcodeCameraScanner from '../components/BarcodeCameraScanner.jsx';
import BarcodePhotoUpload from '../components/BarcodePhotoUpload.jsx';
import { getMeta, getProductByBarcode, getProductByInternalId } from '../api/client.js';

export default function ScanScreen() {
  const navigate = useNavigate();
  const [mode, setMode] = useState('camera'); // 'camera' | 'upload' — co-equal, not primary/fallback
  const [typedBarcode, setTypedBarcode] = useState('');
  const [typedInternalId, setTypedInternalId] = useState('');
  const [resolving, setResolving] = useState(false);
  const [error, setError] = useState('');
  const [meta, setMeta] = useState({ categories: [], idHints: {} });
  const [category, setCategory] = useState('');

  // Asked here, before scanning/uploading anything, on purpose: knowing
  // where the ID tag actually lives on the tool (bumper plate vs. handle
  // stamp vs. no tag at all) only helps if you know it *before* you're
  // pointing a camera at the thing. Showing this after the photo is already
  // taken (which is where it used to live, on the Add Product form) was too
  // late to be useful.
  useEffect(() => {
    getMeta().then(setMeta).catch(() => {});
  }, []);

  const resolveBarcode = useCallback(
    async (barcode, imageFile) => {
      setResolving(true);
      setError('');
      try {
        const product = await getProductByBarcode(barcode);
        if (product) {
          navigate(`/products/${product.id}`);
        } else {
          navigate('/products/new', { state: { barcode, imageFile, category } });
        }
      } catch (err) {
        setError(`Lookup failed: ${err.message}. You can still add this item manually.`);
      } finally {
        setResolving(false);
      }
    },
    [navigate, category]
  );

  function handleTypedSubmit(e) {
    e.preventDefault();
    if (!typedBarcode.trim()) return;
    resolveBarcode(typedBarcode.trim());
  }

  // Renova-assigned ID tag lookup — for tools that were already catalogued
  // (under a self-issued ID, a serial number pulled off a nameplate via OCR,
  // etc.). If it matches an existing product, go straight to it with
  // everything already saved about it. If it doesn't match anything yet,
  // treat it as a new item and carry the ID over so it's not retyped.
  const resolveInternalId = useCallback(
    async (internalId) => {
      setResolving(true);
      setError('');
      try {
        const product = await getProductByInternalId(internalId);
        if (product) {
          navigate(`/products/${product.id}`);
        } else {
          navigate('/products/new', { state: { internalId, category } });
        }
      } catch (err) {
        setError(`Lookup failed: ${err.message}. You can still add this item manually.`);
      } finally {
        setResolving(false);
      }
    },
    [navigate, category]
  );

  function handleTypedInternalIdSubmit(e) {
    e.preventDefault();
    if (!typedInternalId.trim()) return;
    resolveInternalId(typedInternalId.trim());
  }

  // No barcode in the photo at all — went to Add Product directly with
  // whatever OCR could pull off the tag's printed text, pre-filled but
  // never treated as a match against the existing catalog (there's no
  // barcode to match on).
  function handleTagFields(fields, imageFile) {
    navigate('/products/new', { state: { ocrFields: fields, imageFile, category } });
  }

  const idHint = meta.idHints[category];

  return (
    <div>
      <label>What kind of tool is this?</label>
      <select value={category} onChange={(e) => setCategory(e.target.value)}>
        <option value="">Select a category… (optional, but helps)</option>
        {meta.categories.map((c) => (
          <option key={c} value={c}>
            {c}
          </option>
        ))}
      </select>
      {idHint && <div className="hint-box">{idHint}</div>}

      <div className="tab-toggle">
        <button className={mode === 'camera' ? 'active' : ''} onClick={() => setMode('camera')}>
          Live Camera Scan
        </button>
        <button className={mode === 'upload' ? 'active' : ''} onClick={() => setMode('upload')}>
          Upload Photo
        </button>
      </div>

      {resolving && <p className="hint">Looking up barcode…</p>}
      {error && <div className="error-box">{error}</div>}

      {mode === 'camera' ? (
        <BarcodeCameraScanner onDetected={(text) => resolveBarcode(text)} />
      ) : (
        <BarcodePhotoUpload
          onDetected={(text, file) => resolveBarcode(text, file)}
          onTagFieldsExtracted={handleTagFields}
        />
      )}

      <div className="divider">or enter the barcode number</div>

      <form onSubmit={handleTypedSubmit}>
        <input
          type="text"
          inputMode="numeric"
          placeholder="Type barcode number"
          value={typedBarcode}
          onChange={(e) => setTypedBarcode(e.target.value)}
        />
        <p className="hint">
          Also works with a USB/Bluetooth barcode scanner — just tap the field first, then scan.
        </p>
        <button type="submit" className="btn btn-outline">
          Look up
        </button>
      </form>

      <div className="divider">or enter a Renova ID tag number</div>

      <form onSubmit={handleTypedInternalIdSubmit}>
        <input
          type="text"
          placeholder="Type Renova ID"
          value={typedInternalId}
          onChange={(e) => setTypedInternalId(e.target.value)}
        />
        <p className="hint">
          If this tool was already added to the catalog, its saved details fill in automatically.
          If it's new, you'll go straight to Add Product with this ID already in place.
        </p>
        <button type="submit" className="btn btn-outline">
          Look up
        </button>
      </form>
    </div>
  );
}
