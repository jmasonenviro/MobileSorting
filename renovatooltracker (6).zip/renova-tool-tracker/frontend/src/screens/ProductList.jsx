import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { listProducts } from '../api/client.js';

export default function ProductList() {
  const [search, setSearch] = useState('');
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    listProducts(search)
      .then((data) => {
        if (!cancelled) setProducts(data);
      })
      .catch((err) => {
        if (!cancelled) setError(err.message);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [search]);

  return (
    <div>
      <input
        type="text"
        placeholder="Search by name, manufacturer, barcode…"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      {loading && <p className="hint">Loading…</p>}
      {error && <div className="error-box">{error}</div>}
      {!loading && !error && products.length === 0 && (
        <p className="hint">No products found. Scan or add one from the Scan tab.</p>
      )}

      {products.map((p) => (
        <Link key={p.id} to={`/products/${p.id}`} className="list-item">
          <div className="name">{p.name}</div>
          <div className="meta">
            {p.manufacturer || 'Unknown manufacturer'} · {p.category || 'Uncategorized'}
          </div>
        </Link>
      ))}
    </div>
  );
}
