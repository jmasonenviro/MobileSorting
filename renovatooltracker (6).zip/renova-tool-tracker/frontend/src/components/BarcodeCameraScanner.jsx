import { useEffect, useRef, useState } from 'react';
import { BrowserMultiFormatReader, NotFoundException } from '@zxing/library';

/**
 * Live camera barcode scan. Handles "no camera" / permission-denied
 * gracefully — surfaces a clear message and leaves it to the parent screen
 * to offer photo-upload / typed entry as equally valid alternatives.
 */
export default function BarcodeCameraScanner({ onDetected }) {
  const videoRef = useRef(null);
  const readerRef = useRef(null);
  const [status, setStatus] = useState('starting'); // starting | scanning | error
  const [error, setError] = useState('');

  useEffect(() => {
    const reader = new BrowserMultiFormatReader();
    readerRef.current = reader;
    let cancelled = false;

    async function start() {
      try {
        // Prefer the rear/environment-facing camera on phones.
        await reader.decodeFromConstraints(
          { video: { facingMode: { ideal: 'environment' } } },
          videoRef.current,
          (result, err) => {
            if (cancelled) return;
            if (result) {
              onDetected(result.getText());
            } else if (err && !(err instanceof NotFoundException)) {
              // Non-fatal per-frame errors are expected while no barcode is
              // in view; only NotFoundException-adjacent noise is ignored.
            }
          }
        );
        if (!cancelled) setStatus('scanning');
      } catch (err) {
        if (cancelled) return;
        setStatus('error');
        if (err?.name === 'NotAllowedError') {
          setError('Camera access was denied. Use photo upload or type the barcode instead.');
        } else if (err?.name === 'NotFoundError' || err?.name === 'OverconstrainedError') {
          setError('No camera was found on this device. Use photo upload or type the barcode instead.');
        } else {
          setError('Could not start the camera. Use photo upload or type the barcode instead.');
        }
      }
    }

    start();

    return () => {
      cancelled = true;
      try {
        reader.reset();
      } catch {
        /* no-op */
      }
    };
  }, [onDetected]);

  return (
    <div>
      <video ref={videoRef} className="scanner-video" muted playsInline />
      {status === 'starting' && <p className="hint">Starting camera…</p>}
      {status === 'scanning' && <p className="hint">Point the camera at a barcode.</p>}
      {status === 'error' && <div className="error-box">{error}</div>}
    </div>
  );
}
