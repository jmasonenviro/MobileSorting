// Simple bottom-sheet modal used by the On Hand / Checked Out / Times Out
// detail views on the product page. Not a full-screen route on purpose —
// these are quick "tap for details" lookups you dismiss and go right back
// to what you were doing.
export default function Modal({ title, onClose, children }) {
  return (
    <div
      className="modal-overlay open"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="modal-sheet">
        <div className="modal-head">
          <h3>{title}</h3>
          <button className="modal-close" onClick={onClose} aria-label="Close">
            &times;
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}
