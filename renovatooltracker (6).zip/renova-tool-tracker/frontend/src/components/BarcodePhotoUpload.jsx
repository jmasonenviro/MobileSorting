import { useRef, useState } from 'react';
import { BrowserMultiFormatReader } from '@zxing/library';
import { hasUsefulTagFields, readEquipmentTag } from '../lib/ocr.js';

/**
 * First-class photo-upload path: decode a barcode from an attached image
 * client-side (same library as the live scanner). This is what makes the
 * app work on desktop with no camera, and it's how hardware USB/Bluetooth
 * scanners fit in too — most of those just type digits into a focused
 * field, which the typed-entry fallback below already covers.
 *
 * If there's no barcode in the photo at all — common for heavy equipment
 * ID plates and tool labels, which are usually just printed text — this
 * falls back to reading the text directly (OCR) and pulling out a
 * model/serial/manufacturer guess, rather than giving up immediately.
 */
export default function BarcodePhotoUpload({ onDetected, onTagFieldsExtracted }) {
  const inputRef = useRef(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [status, setStatus] = useState('idle'); // idle | decoding | reading-tag | error
  const [error, setError] = useState('');

  async function handleFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;

    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
    setStatus('decoding');
    setError('');

    try {
      const reader = new BrowserMultiFormatReader();
      const result = await reader.decodeFromImageUrl(url);
      setStatus('idle');
      onDetected(result.getText(), file);
      return;
    } catch {
      // No barcode found — fall through and try reading it as printed text.
    }

    setStatus('reading-tag');
    try {
      const fields = await readEquipmentTag(url);
      if (hasUsefulTagFields(fields)) {
        setStatus('idle');
        onTagFieldsExtracted(fields, file);
        return;
      }
    } catch {
      // OCR itself failed to run — fall through to the generic error below.
    }

    setStatus('error');
    setError(
      "Couldn't find a barcode or readable text in that photo. Try a clearer, closer photo, or fill in the details manually below."
    );
  }

  return (
    <div>
      {previewUrl && <img src={previewUrl} alt="Barcode or tag preview" className="upload-preview" />}
      <button type="button" className="btn btn-primary" onClick={() => inputRef.current?.click()}>
        {previewUrl ? 'Choose a different photo' : 'Upload / take a photo of the barcode or ID tag'}
      </button>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFile}
        style={{ display: 'none' }}
      />
      {status === 'decoding' && <p className="hint">Reading barcode…</p>}
      {status === 'reading-tag' && (
        <p className="hint">No barcode found — trying to read the tag's text instead…</p>
      )}
      {status === 'error' && <div className="error-box">{error}</div>}
    </div>
  );
}
