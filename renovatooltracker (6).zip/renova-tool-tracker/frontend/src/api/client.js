const BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:4000';

async function handle(res) {
  const text = await res.text();
  const json = text ? JSON.parse(text) : {};
  if (!res.ok) {
    const err = new Error(json.error || `Request failed (${res.status})`);
    err.status = res.status;
    err.body = json;
    throw err;
  }
  return json;
}

export function getMeta() {
  return fetch(`${BASE_URL}/products/meta`).then(handle);
}

export function listProducts(search) {
  const qs = search ? `?search=${encodeURIComponent(search)}` : '';
  return fetch(`${BASE_URL}/products${qs}`).then(handle);
}

export async function getProductByBarcode(barcode) {
  const res = await fetch(`${BASE_URL}/products/barcode/${encodeURIComponent(barcode)}`);
  if (res.status === 404) return null;
  return handle(res);
}

export async function getProductByInternalId(internalId) {
  const res = await fetch(`${BASE_URL}/products/internal-id/${encodeURIComponent(internalId)}`);
  if (res.status === 404) return null;
  return handle(res);
}

export function getProduct(id) {
  return fetch(`${BASE_URL}/products/${id}`).then(handle);
}

export function createProduct(formData) {
  return fetch(`${BASE_URL}/products`, { method: 'POST', body: formData }).then(handle);
}

export function updateProduct(id, formData) {
  return fetch(`${BASE_URL}/products/${id}`, { method: 'PUT', body: formData }).then(handle);
}

export function createPurchase(data) {
  return fetch(`${BASE_URL}/purchases`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  }).then(handle);
}

export function checkOut(data) {
  return fetch(`${BASE_URL}/transactions/checkout`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  }).then(handle);
}

export function checkIn(data) {
  return fetch(`${BASE_URL}/transactions/checkin`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  }).then(handle);
}

export function lookupBarcode(barcode) {
  return fetch(`${BASE_URL}/lookup/${encodeURIComponent(barcode)}`).then(handle);
}

export function barcodeImageSrc(product) {
  if (!product?.barcodeImage?.data) return null;
  const mime = product.barcodeImage.mimeType || 'image/jpeg';
  return `data:${mime};base64,${product.barcodeImage.data}`;
}
