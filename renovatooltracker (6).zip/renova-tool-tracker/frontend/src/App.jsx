import { NavLink, Route, Routes } from 'react-router-dom';
import ScanScreen from './screens/ScanScreen.jsx';
import ProductList from './screens/ProductList.jsx';
import ProductDetail from './screens/ProductDetail.jsx';
import AddEditProduct from './screens/AddEditProduct.jsx';
import AddPurchase from './screens/AddPurchase.jsx';

export default function App() {
  return (
    <div className="app-shell">
      <header className="app-header">
        <h1>Renova Tool Tracker</h1>
        <p>Renova Environmental Company, Inc.</p>
      </header>

      <main className="app-main">
        <Routes>
          <Route path="/" element={<ScanScreen />} />
          <Route path="/products" element={<ProductList />} />
          <Route path="/products/new" element={<AddEditProduct mode="create" />} />
          <Route path="/products/:id" element={<ProductDetail />} />
          <Route path="/products/:id/edit" element={<AddEditProduct mode="edit" />} />
          <Route path="/products/:id/purchases/new" element={<AddPurchase />} />
        </Routes>
      </main>

      <nav className="bottom-nav">
        <NavLink to="/" end className={({ isActive }) => (isActive ? 'active' : '')}>
          Scan
        </NavLink>
        <NavLink to="/products" className={({ isActive }) => (isActive ? 'active' : '')}>
          Browse
        </NavLink>
      </nav>
    </div>
  );
}
