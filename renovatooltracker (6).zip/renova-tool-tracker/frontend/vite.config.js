import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Mobile-first PWA-ish web app; runs as a plain website on desktop too.
export default defineConfig({
  plugins: [react()],
  server: {
    host: true, // reachable from a phone on the same LAN during dev
    port: 5173,
    // Forward /api/* to the backend running in the same container. This
    // keeps the browser talking to a single origin (this dev server's own
    // URL) instead of making a separate cross-origin request to the
    // backend's own preview URL — some corporate networks/proxies treat
    // background fetches to a second address differently than a page you
    // navigated to directly, which this sidesteps entirely.
    proxy: {
      '/api': {
        target: 'http://localhost:4000',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, ''),
      },
    },
  },
});
