# Renova Tool Tracker

Mobile-first web app for tracking construction products by barcode, backed by QuickBase.
Built for Renova Environmental Company, Inc.

## What's here

- `backend/` — thin Node/Express API. Holds the QuickBase user token and any external
  lookup API keys server-side; the browser never sees them.
- `frontend/` — mobile-first React (Vite) web app. Works as a plain website on desktop too.

## Status against the build order

1. ✅ QuickBase tables + REST endpoints — code is written and tested against an
   in-memory mock store (no live QuickBase account was available while building this).
   **Not yet smoke-tested against real QuickBase.** See "Connecting QuickBase" below —
   that first run should be treated as a smoke test.
2. ✅ Product detail + add-product screens — built and tested end-to-end in the browser.
3. ✅ Purchases, check-out/check-in, on-hand math — built and tested end-to-end,
   including the overdraw guard (can't check out more than is on hand).
4. ✅ Photo-upload decoding — built and verified with real generated barcode images
   decoding correctly client-side via @zxing/library.
5. ✅ Live camera scanning — built; verified it initializes and requests the rear
   camera correctly. Couldn't verify against a real physical camera in this
   environment — test on an actual phone before relying on it.
6. ⏳ GEPIR + product-API pre-fill — intentionally stubbed with TODOs (no API keys
   provided yet). The `/lookup` endpoint and pre-fill wiring both work; each source
   just returns `not_configured` until keys are added to `.env`.

"Barcode not found," "no camera," and "lookup failed" are all handled gracefully
(tested) rather than left as loose ends.

## Equipment ID-tag photo reading (OCR)

Beyond the original build order, the photo-upload path also handles equipment that
has no barcode at all — common for heavy equipment nameplates and power tool labels,
which are usually just printed/stamped text. If `@zxing/library` can't find a barcode
in the uploaded photo, it falls back to reading the text directly (OCR, via
Tesseract.js) and pulls out a best-effort model/serial number/manufacturer guess
(see `frontend/src/lib/ocr.js`), pre-filling the Add Product form the same way the
GEPIR/product-API lookups do — never blocking, always editable, always flagged for
the user to double-check before saving.

This is free (no API key, no per-image cost, runs entirely in the browser) but it's
genuinely best-effort: it'll read a clean, well-lit, straight-on photo of a tag
reasonably well, and it'll likely struggle with a worn, scratched, or heavily angled
one. That's an inherent limitation of OCR technology, not a bug — if this ever needs
to be more reliable on rough real-world tags, the honest upgrade path is sending the
photo to an AI vision model instead (far better at messy real-world images), which
needs an API key and has a small per-image cost, so that's a deliberate future
decision rather than something built in now.

Tesseract.js's worker/engine/language-data files are bundled locally under
`frontend/public/tesseract/` rather than fetched from its default CDN at runtime —
same reasoning as the `/api` proxy setup above: some networks intercept or block
requests to third-party CDN domains, which would make OCR silently fail. If
`tesseract.js`, `tesseract.js-core`, or `@tesseract.js-data/eng` ever get upgraded,
those files need to be re-copied from the new package versions into
`frontend/public/tesseract/` — see the comment at the top of `frontend/src/lib/ocr.js`
for exactly which files come from where.

## Running it locally

```bash
# Backend
cd backend
cp .env.example .env      # defaults to the in-memory mock store — no QuickBase needed yet
npm install
npm run dev                # http://localhost:4000

# Frontend (separate terminal)
cd frontend
cp .env.example .env
npm install
npm run dev                 # http://localhost:5173
```

Open `http://localhost:5173` on your phone (same Wi-Fi) or desktop browser. With no
QuickBase configured, the backend automatically uses an in-memory store so you can try
every screen immediately — data resets when the backend restarts.

## Connecting QuickBase

1. Create an app in QuickBase (or use an existing one) and get its App ID and your
   realm hostname (e.g. `renova.quickbase.com`) and a user token with access to it.
2. Fill in `backend/.env`: `QB_REALM_HOSTNAME`, `QB_USER_TOKEN`, `QB_APP_ID`.
3. Run `npm run provision` from `backend/` — this creates the Products, Purchases,
   and Transactions tables with all the fields from the build prompt, and prints
   the three table IDs.
4. Paste those into `QB_TABLE_PRODUCTS`, `QB_TABLE_PURCHASES`, `QB_TABLE_TRANSACTIONS`
   in `.env` and restart the backend. It will log "Using QuickBase as the data store."
5. Do a smoke test: add one product, one purchase, one check-out/check-in through the
   app, and confirm the records look right in QuickBase directly. The field-ID
   resolution happens at startup and raises a clear error naming any missing field, if
   something doesn't line up with what provisioning created.

Note: this intentionally does not use QuickBase's native table-to-table "relationship"
feature — Purchases and Transactions store the related product's plain Record ID#,
and the backend does the joins. That was a deliberate choice to avoid guessing at a
relationship-API request shape with no live account to verify it against; it can be
swapped for native QuickBase relationships/lookups later without changing the app's
API. See the comment at the top of `backend/src/quickbase/client.js`.

## Adding the lookup API keys later

`backend/src/lookups.js` has one function per source (GEPIR, Icecat, UPCitemdb,
Go-UPC), each with a `TODO` marking exactly where to add the real API call once a key
is available. Add the key to `.env`, implement the function, done — nothing else
needs to change, since the Add Product form already calls `/lookup` and merges
whatever comes back.

## Equipment ID-tag guidance

The Scan screen now asks "What kind of tool is this?" up front, before you scan or
upload anything, and immediately shows hint text for where a factory ID tag actually
tends to live for that category (Heavy Equipment / Power Tool / Hand Tool / Other) —
see `CATEGORY_ID_HINTS` in `backend/src/quickbase/schema.js`. That's deliberately
asked before the photo step now; it used to only show up on the Add Product form,
which was after the photo was already taken and too late to be useful. Whatever
category gets picked on the Scan screen carries through automatically to Add Product
(no need to pick it twice), and the same hint still shows there too. Hand Tool has no
factory ID at all, so Name and Manufacturer are required fields for that category
rather than optional pre-fill.

Self-issued asset tags/barcodes for hand tools (so future scans resolve exactly
instead of relying on typed name/manufacturer) were discussed but intentionally left
unbuilt for now — flagged as an open decision. There's a clean extension point
(`internalId` field, already separate from `barcode`) if that gets picked up later.

## Looking a tool up by its Renova ID

The Scan screen has a second "or enter a Renova ID tag number" field, separate from
the barcode one. Typing a Renova-assigned ID (an `internalId` — see above) that's
already in the catalog jumps straight to that product with everything already saved
about it (name, manufacturer, category, etc.) — nothing needs to be re-typed. Typing
one that isn't in the catalog yet goes to Add Product with that ID already filled in,
so the details only need to be entered once; the next person who types that same ID
gets them automatically. This works the same whether the ID came from a
Renova-printed asset tag or was typed in from the factory serial number OCR pulled
off a nameplate. Backed by `GET /products/internal-id/:internalId` on the backend,
mirroring the existing barcode-lookup endpoint.

## Check-out duration, overdue tracking, and the On Hand / Checked Out / Times Out detail views

Check-out now asks "How many days do you expect to use this?" instead of picking a
specific return date (`Expected Days`, numeric, replacing the old `Expected Return`
date field in `backend/src/quickbase/schema.js`). Overdue-ness is computed from that:
`checkOutDateTime + Expected Days` vs. now, in `frontend/src/lib/checkoutMath.js` —
nothing is stored as "overdue," it's calculated fresh every time the page renders, so
it's always current. Every open check-out (on the product page and in Use History)
shows a green/amber/red pill: green while there's time left, amber right at the
deadline, red and counting once it's overdue. Closed check-outs (already returned)
show whether they came back on time or late, using the same math.

The On Hand, Checked Out, and Times Out numbers on the product page are now buttons —
tapping any of them opens a detail view:
- **On Hand** — which purchase batch(es) the on-hand quantity is made up of, with a
  Purchased/Out/On Hand summary.
- **Checked Out** — who has what, from which batch, and its overdue status, one row
  per open check-out.
- **Times Out** — the complete lifetime check-out history for this tool, out and back
  dates, and whether each was returned on time.

Design note on "which batch": the Products table still has one Barcode/Internal ID
per tool TYPE, not a unique tag per physical unit — this was a deliberate scope
decision (see below) rather than an oversight. So "which purchase batch is this
on-hand/checked-out unit from" is inferred by `inferBatches()` in
`frontend/src/lib/checkoutMath.js`, which replays purchase/check-out/check-in history
assuming units get used oldest-purchased-first (FIFO), the standard inventory-
accounting assumption. It's a best-effort estimate, not a tracked fact, and every
place it's shown says so. If a physical unit actually gets grabbed newest-first in
practice, this attribution could be wrong for that item.

This was validated first as a clickable HTML mockup with fake data before being built
for real, including a version with a truly unique tag per physical unit (so each tool
could be individually tracked with its own history, not just inferred). That's
deliberately **not** built here — it would mean adding a real "Units" concept (a table
of individual physical items, each with its own tag, not just one row per tool type)
which is a bigger data-model change than anything else in this app. Worth revisiting
if Renova ever needs to say "this exact hammer drill, not just one of our five," e.g.
for warranty claims, tracking a specific unit's damage history, or theft/loss
investigation on a particular serial number.

## What still needs human review before this goes live

- The QuickBase integration itself (steps above) — untested against a real account.
- Whatever QuickBase security/permissions model Renova wants (who can see cost data
  on Purchases, who can edit vs. just check items in/out).
- Deployment/hosting decision — this was built and tested locally only.
