import express from 'express';
import cors from 'cors';
import { config } from './config.js';
import productsRouter from './routes/products.js';
import purchasesRouter from './routes/purchases.js';
import transactionsRouter from './routes/transactions.js';
import lookupRouter from './routes/lookup.js';

const app = express();

app.use(cors({ origin: config.corsOrigin }));
app.use(express.json());

app.get('/health', (req, res) => res.json({ ok: true }));

app.use('/products', productsRouter);
app.use('/purchases', purchasesRouter);
app.use('/transactions', transactionsRouter);
app.use('/lookup', lookupRouter);

// Centralized error handler — keeps route handlers free of try/catch noise
// for anything unexpected, and never leaks stack traces to the client.
app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status && err.status < 500 ? err.status : 500).json({
    error: err.message || 'Internal server error',
  });
});

app.listen(config.port, () => {
  console.log(`Renova tool tracker backend listening on http://localhost:${config.port}`);
});
