import 'dotenv/config';

export const config = {
  port: Number(process.env.PORT || 4000),
  corsOrigin: process.env.CORS_ORIGIN || 'http://localhost:5173',

  quickbase: {
    realmHostname: process.env.QB_REALM_HOSTNAME || '',
    userToken: process.env.QB_USER_TOKEN || '',
    appId: process.env.QB_APP_ID || '',
    tables: {
      products: process.env.QB_TABLE_PRODUCTS || '',
      purchases: process.env.QB_TABLE_PURCHASES || '',
      transactions: process.env.QB_TABLE_TRANSACTIONS || '',
    },
  },

  lookups: {
    gepirBaseUrl: process.env.GEPIR_API_BASE_URL || '',
    icecatApiKey: process.env.ICECAT_API_KEY || '',
    upcItemDbApiKey: process.env.UPCITEMDB_API_KEY || '',
    goUpcApiKey: process.env.GO_UPC_API_KEY || '',
  },
};

// True once all three required QuickBase identifiers are present. Until then,
// the app runs against the in-memory mock store so it stays fully usable.
export const isQuickBaseConfigured = () =>
  Boolean(
    config.quickbase.realmHostname &&
      config.quickbase.userToken &&
      config.quickbase.appId
  );
