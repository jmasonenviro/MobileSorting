// One-time setup script: creates the Products, Purchases, and Transactions
// tables (and their fields) in QuickBase from the schema in schema.js.
//
// Usage:
//   1. Fill in QB_REALM_HOSTNAME, QB_USER_TOKEN, and QB_APP_ID in .env
//      (the app must already exist in QuickBase — this script creates
//      tables inside it, not the app itself).
//   2. npm run provision
//   3. Copy the printed QB_TABLE_* values into your .env.
//
// Safe to inspect before running — it only creates tables/fields, it does
// not touch existing data. Re-running it will create duplicate tables if
// the QB_TABLE_* env vars are already set, so only run it once per app.
//
// NOTE: as called out in client.js, this deliberately skips QuickBase's
// native table-to-table relationship feature. This is a first live
// integration with no QuickBase account available at build time to test
// against — treat this run as a smoke test, and check the printed output
// against your QuickBase app afterward before relying on it.

import { config, isQuickBaseConfigured } from '../config.js';
import { createTable, createField } from './client.js';
import { TABLES } from './schema.js';

async function provisionTable(key, def) {
  console.log(`\nCreating table "${def.name}"...`);
  const table = await createTable({ name: def.name, description: def.description });
  console.log(`  table id: ${table.id}`);

  for (const field of def.fields) {
    const created = await createField(table.id, {
      label: field.label,
      type: field.type,
      choices: field.choices,
    });
    console.log(`  field "${field.label}" -> id ${created.id} (${field.type})`);
  }

  return table.id;
}

async function main() {
  if (!config.quickbase.appId) {
    console.error(
      'QB_APP_ID is not set. Create an app in QuickBase first, then set QB_REALM_HOSTNAME, QB_USER_TOKEN, and QB_APP_ID in .env before running this script.'
    );
    process.exit(1);
  }
  if (!isQuickBaseConfigured()) {
    console.error(
      'Missing QuickBase config. Set QB_REALM_HOSTNAME, QB_USER_TOKEN, and QB_APP_ID in .env.'
    );
    process.exit(1);
  }

  const ids = {};
  for (const [key, def] of Object.entries(TABLES)) {
    ids[key] = await provisionTable(key, def);
  }

  console.log('\nDone. Add these to your .env:\n');
  console.log(`QB_TABLE_PRODUCTS=${ids.products}`);
  console.log(`QB_TABLE_PURCHASES=${ids.purchases}`);
  console.log(`QB_TABLE_TRANSACTIONS=${ids.transactions}`);
}

main().catch((err) => {
  console.error('\nProvisioning failed:', err.message);
  if (err.details) console.error(JSON.stringify(err.details, null, 2));
  process.exit(1);
});
