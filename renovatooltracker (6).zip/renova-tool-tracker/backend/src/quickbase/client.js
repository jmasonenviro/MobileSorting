// Minimal QuickBase REST API (v1) client used by both the provisioning
// script and the QuickBase-backed data store.
//
// Docs: https://developer.quickbase.com/
//
// This file intentionally avoids QuickBase's native table-to-table
// "relationship" feature (POST /tables/{id}/relationship) — its exact
// request shape varies across QuickBase's own docs/tooling and isn't worth
// guessing at without a live account to verify against. Instead, Purchases
// and Transactions store the related Product's plain numeric Record ID
// (#) and the backend joins them in `lib/onHand.js` and the route
// handlers. This is simpler to provision reliably and easy to reason
// about; it can be swapped for native QuickBase relationships/lookups
// later without changing the app's public API.

import { config } from '../config.js';

const BASE_URL = 'https://api.quickbase.com/v1';

function authHeaders() {
  const { realmHostname, userToken } = config.quickbase;
  if (!realmHostname || !userToken) {
    throw new Error(
      'QuickBase is not configured (missing QB_REALM_HOSTNAME / QB_USER_TOKEN).'
    );
  }
  return {
    'QB-Realm-Hostname': realmHostname,
    Authorization: `QB-USER-TOKEN ${userToken}`,
    'Content-Type': 'application/json',
  };
}

async function qbFetch(path, { method = 'GET', body } = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: authHeaders(),
    body: body ? JSON.stringify(body) : undefined,
  });

  const text = await res.text();
  let json;
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    json = { raw: text };
  }

  if (!res.ok) {
    const message =
      json?.message || json?.description || `QuickBase API error (${res.status})`;
    const err = new Error(message);
    err.status = res.status;
    err.details = json;
    throw err;
  }

  return json;
}

// ---- Tables ----

export function createTable({ name, description }) {
  return qbFetch(`/tables?appId=${config.quickbase.appId}`, {
    method: 'POST',
    body: { name, description },
  });
}

export function getFields(tableId) {
  return qbFetch(`/fields?tableId=${tableId}`);
}

export function createField(tableId, { label, type, choices }) {
  const body = { label, fieldType: type };
  if (choices?.length) {
    body.properties = { choices };
  }
  return qbFetch(`/fields?tableId=${tableId}`, { method: 'POST', body });
}

// ---- Records ----

/**
 * Insert or update records. `data` is an array of objects keyed by field ID
 * (as strings), e.g. { "6": { value: "Acme Drill" } }. Include a "3" key
 * (the built-in Record ID# field) to update an existing record.
 */
export function upsertRecords(tableId, data, fieldsToReturn) {
  return qbFetch('/records', {
    method: 'POST',
    body: { to: tableId, data, fieldsToReturn },
  });
}

export function queryRecords({ from, select, where, sortBy, options }) {
  return qbFetch('/records/query', {
    method: 'POST',
    body: { from, select, where, sortBy, options },
  });
}

export function deleteRecords(tableId, where) {
  return qbFetch('/records', {
    method: 'DELETE',
    body: { from: tableId, where },
  });
}

// ---- File attachments ----
// QuickBase file attachment fields accept { value: { fileName, data } }
// where `data` is a base64-encoded string, sent as part of a normal
// upsertRecords() call against a "file" type field.
export function toFileAttachmentValue(fileName, base64Data) {
  return { value: { fileName, data: base64Data } };
}
