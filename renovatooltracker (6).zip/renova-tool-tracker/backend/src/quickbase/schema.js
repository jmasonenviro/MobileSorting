// Canonical definition of the three QuickBase tables described in the build
// prompt. This is the single source of truth used by:
//   - provision.js       (creates the tables/fields in QuickBase via the API)
//   - quickbaseStore.js  (maps field labels -> field IDs at runtime)
//   - mockStore.js       (keeps the same shape so swapping stores is a no-op)
//
// NOTE: QuickBase's Tables/Fields REST API shapes below reflect QuickBase's
// documented API v1 as of this build. QuickBase occasionally changes field
// type codes and endpoint details — the first live run of `npm run
// provision` should be treated as a smoke test, and any request/response
// mismatches should be checked against QuickBase's current API docs
// (https://developer.quickbase.com/) rather than assumed correct.

export const CATEGORIES = [
  'Heavy Equipment',
  'Power Tool',
  'Hand Tool',
  'Other',
];

// Tier-aware "where's the ID tag" guidance shown on the Add Product form.
// See EQUIPMENT ID-TAG GUIDANCE section of the build prompt for sourcing.
export const CATEGORY_ID_HINTS = {
  'Heavy Equipment':
    'Check the cab area, chassis, boom base, or engine compartment for a metal ID plate with model and serial number. Exact location varies by manufacturer and model.',
  'Power Tool':
    'Check the handle, battery compartment, or body of the tool for a printed or stamped model/serial label. This label can wear off with heavy use.',
  'Hand Tool':
    "This type of tool typically has no factory serial number. Enter the tool name and manufacturer yourself — both are required for this category.",
  Other:
    'Look for a manufacturer label or plate on the item. If none exists, enter what you know manually.',
};

// Categories where no reliable factory ID exists, so Name + Manufacturer are
// required (not just best-effort pre-fill) on the Add Product form.
export const CATEGORIES_REQUIRING_MANUAL_ID = ['Hand Tool'];

export const TRANSACTION_TYPES = ['Check-Out', 'Check-In'];

export const CONDITIONS = ['Good', 'Fair', 'Damaged', 'Needs Repair'];

/**
 * Field definitions per table. `type` uses QuickBase field type codes
 * (see https://developer.quickbase.com/ "Field types"). `label` is what
 * both humans and the app's field-label-based lookups key off of.
 */
export const TABLES = {
  products: {
    name: 'Products',
    description: 'Product catalog — source of truth for what an item is.',
    fields: [
      { label: 'Name', type: 'text', required: true },
      { label: 'Internal ID', type: 'text' },
      { label: 'Manufacturer', type: 'text' },
      { label: 'Barcode', type: 'text' },
      { label: 'Category', type: 'text', choices: CATEGORIES },
      { label: 'Unit of Measure', type: 'text' },
      { label: 'Barcode Image', type: 'file' },
      { label: 'Notes', type: 'text-multi-line' },
    ],
  },
  purchases: {
    name: 'Purchases',
    description: 'One row per purchase; many per product. Price lives here.',
    fields: [
      { label: 'Product', type: 'numeric', isProductReference: true },
      { label: 'Vendor', type: 'text' },
      { label: 'Purchase Date', type: 'date' },
      { label: 'Quantity', type: 'numeric' },
      { label: 'Unit Cost', type: 'currency' },
      { label: 'Total Cost', type: 'currency' },
      { label: 'PO Number', type: 'text' },
      { label: 'Notes', type: 'text-multi-line' },
    ],
  },
  transactions: {
    name: 'Transactions',
    description:
      'Check-out and check-in events for a product. Type distinguishes the two.',
    fields: [
      { label: 'Product', type: 'numeric', isProductReference: true },
      { label: 'Type', type: 'text', choices: TRANSACTION_TYPES },
      // Check-out fields
      { label: 'Person', type: 'text' },
      { label: 'Quantity', type: 'numeric' },
      { label: 'Job Site', type: 'text' },
      { label: 'Check-Out Date-Time', type: 'date-time' },
      // How many days the person expects to need it, asked at check-out
      // time instead of picking a specific return date — overdue-ness is
      // computed as (Check-Out Date-Time + Expected Days) vs. now, in the
      // frontend (see frontend/src/lib/checkoutMath.js).
      { label: 'Expected Days', type: 'numeric' },
      // Check-in fields
      { label: 'Related Checkout', type: 'numeric' },
      { label: 'Quantity Returned', type: 'numeric' },
      { label: 'Condition', type: 'text', choices: CONDITIONS },
      { label: 'Check-In Date-Time', type: 'date-time' },
      { label: 'Notes', type: 'text-multi-line' },
    ],
  },
};
