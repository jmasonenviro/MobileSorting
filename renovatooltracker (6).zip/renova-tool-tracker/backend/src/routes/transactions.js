import { Router } from 'express';
import store from '../store/index.js';
import { computeOnHand } from '../lib/onHand.js';

const router = Router();

router.get('/', async (req, res, next) => {
  try {
    if (!req.query.productId) {
      return res.status(400).json({ error: 'productId query param is required' });
    }
    const transactions = await store.listTransactionsForProduct(req.query.productId);
    res.json(transactions);
  } catch (err) {
    next(err);
  }
});

router.post('/checkout', async (req, res, next) => {
  try {
    const { productId, person, quantity, jobSite, expectedDays } = req.body;
    if (!productId || !person || !quantity || !expectedDays) {
      return res
        .status(400)
        .json({ error: 'productId, person, quantity, and expectedDays are required' });
    }
    if (Number(expectedDays) < 1) {
      return res.status(400).json({ error: 'expectedDays must be at least 1' });
    }

    const [purchases, transactions] = await Promise.all([
      store.listPurchasesForProduct(productId),
      store.listTransactionsForProduct(productId),
    ]);
    const { onHand } = computeOnHand({ purchases, transactions });
    const qty = Number(quantity);
    if (qty > onHand) {
      return res.status(409).json({
        error: `Only ${onHand} on hand — cannot check out ${qty}.`,
        onHand,
      });
    }

    const transaction = await store.createTransaction({
      productId: Number(productId),
      type: 'Check-Out',
      person,
      quantity: qty,
      jobSite: jobSite || null,
      checkOutDateTime: new Date().toISOString(),
      expectedDays: Number(expectedDays),
    });
    res.status(201).json(transaction);
  } catch (err) {
    next(err);
  }
});

router.post('/checkin', async (req, res, next) => {
  try {
    const { productId, relatedCheckoutId, quantityReturned, condition, notes } = req.body;
    if (!productId || !relatedCheckoutId || !quantityReturned) {
      return res
        .status(400)
        .json({ error: 'productId, relatedCheckoutId, and quantityReturned are required' });
    }

    const transaction = await store.createTransaction({
      productId: Number(productId),
      type: 'Check-In',
      relatedCheckoutId: Number(relatedCheckoutId),
      quantityReturned: Number(quantityReturned),
      condition: condition || null,
      checkInDateTime: new Date().toISOString(),
      notes: notes || null,
    });
    res.status(201).json(transaction);
  } catch (err) {
    next(err);
  }
});

export default router;
