import { Router } from 'express';
import store from '../store/index.js';

const router = Router();

router.get('/', async (req, res, next) => {
  try {
    if (!req.query.productId) {
      return res.status(400).json({ error: 'productId query param is required' });
    }
    const purchases = await store.listPurchasesForProduct(req.query.productId);
    res.json(purchases);
  } catch (err) {
    next(err);
  }
});

router.post('/', async (req, res, next) => {
  try {
    const { productId, vendor, purchaseDate, quantity, unitCost, poNumber, notes } = req.body;
    if (!productId || !quantity) {
      return res.status(400).json({ error: 'productId and quantity are required' });
    }
    const qty = Number(quantity);
    const cost = Number(unitCost) || 0;
    const purchase = await store.createPurchase({
      productId: Number(productId),
      vendor: vendor || null,
      purchaseDate: purchaseDate || null,
      quantity: qty,
      unitCost: cost,
      totalCost: Math.round(qty * cost * 100) / 100,
      poNumber: poNumber || null,
      notes: notes || null,
    });
    res.status(201).json(purchase);
  } catch (err) {
    next(err);
  }
});

export default router;
