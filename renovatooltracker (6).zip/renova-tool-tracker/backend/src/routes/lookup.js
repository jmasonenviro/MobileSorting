import { Router } from 'express';
import { runLookups } from '../lookups.js';

const router = Router();

// Best-effort only — always returns 200 even if every source is
// unconfigured/empty, since the Add Product form must never block on this.
router.get('/:barcode', async (req, res, next) => {
  try {
    const result = await runLookups(req.params.barcode);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

export default router;
