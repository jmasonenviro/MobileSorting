import { Router } from 'express';
import multer from 'multer';
import store from '../store/index.js';
import { computeOnHand } from '../lib/onHand.js';
import { CATEGORIES, CATEGORY_ID_HINTS, CATEGORIES_REQUIRING_MANUAL_ID } from '../quickbase/schema.js';

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 8 * 1024 * 1024 } });
const router = Router();

// Metadata the Add/Edit Product form needs: category list + tier-aware hints.
router.get('/meta', (req, res) => {
  res.json({
    categories: CATEGORIES,
    idHints: CATEGORY_ID_HINTS,
    categoriesRequiringManualId: CATEGORIES_REQUIRING_MANUAL_ID,
  });
});

router.get('/', async (req, res, next) => {
  try {
    const products = await store.listProducts({ search: req.query.search });
    res.json(products);
  } catch (err) {
    next(err);
  }
});

router.get('/barcode/:barcode', async (req, res, next) => {
  try {
    const product = await store.getProductByBarcode(req.params.barcode);
    if (!product) return res.status(404).json({ error: 'not_found', barcode: req.params.barcode });
    res.json(product);
  } catch (err) {
    next(err);
  }
});

router.get('/internal-id/:internalId', async (req, res, next) => {
  try {
    const product = await store.getProductByInternalId(req.params.internalId);
    if (!product) return res.status(404).json({ error: 'not_found', internalId: req.params.internalId });
    res.json(product);
  } catch (err) {
    next(err);
  }
});

router.get('/:id', async (req, res, next) => {
  try {
    const product = await store.getProductById(req.params.id);
    if (!product) return res.status(404).json({ error: 'not_found' });

    const [purchases, transactions] = await Promise.all([
      store.listPurchasesForProduct(req.params.id),
      store.listTransactionsForProduct(req.params.id),
    ]);

    res.json({
      ...product,
      purchases,
      transactions,
      ...computeOnHand({ purchases, transactions }),
    });
  } catch (err) {
    next(err);
  }
});

function buildBarcodeImage(file) {
  if (!file) return undefined;
  return {
    fileName: file.originalname,
    mimeType: file.mimetype,
    data: file.buffer.toString('base64'),
  };
}

router.post('/', upload.single('barcodeImage'), async (req, res, next) => {
  try {
    const { name, internalId, manufacturer, barcode, category, unitOfMeasure, notes } = req.body;
    if (!name) return res.status(400).json({ error: 'name is required' });
    if (CATEGORIES_REQUIRING_MANUAL_ID.includes(category) && (!name || !manufacturer)) {
      return res.status(400).json({
        error: `Category "${category}" has no factory ID — Name and Manufacturer are both required.`,
      });
    }

    const fields = {
      name,
      internalId: internalId || null,
      manufacturer: manufacturer || null,
      barcode: barcode || null,
      category: category || null,
      unitOfMeasure: unitOfMeasure || null,
      notes: notes || null,
    };
    const image = buildBarcodeImage(req.file);
    if (image) fields.barcodeImage = image;

    const product = await store.createProduct(fields);
    res.status(201).json(product);
  } catch (err) {
    next(err);
  }
});

router.put('/:id', upload.single('barcodeImage'), async (req, res, next) => {
  try {
    const { name, internalId, manufacturer, barcode, category, unitOfMeasure, notes } = req.body;
    const fields = {};
    if (name !== undefined) fields.name = name;
    if (internalId !== undefined) fields.internalId = internalId;
    if (manufacturer !== undefined) fields.manufacturer = manufacturer;
    if (barcode !== undefined) fields.barcode = barcode;
    if (category !== undefined) fields.category = category;
    if (unitOfMeasure !== undefined) fields.unitOfMeasure = unitOfMeasure;
    if (notes !== undefined) fields.notes = notes;
    const image = buildBarcodeImage(req.file);
    if (image) fields.barcodeImage = image;

    const product = await store.updateProduct(req.params.id, fields);
    res.json(product);
  } catch (err) {
    next(err);
  }
});

export default router;
