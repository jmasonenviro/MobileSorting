// In-memory data store used automatically when QuickBase isn't configured
// yet (see config.js / isQuickBaseConfigured). Implements the same
// interface as quickbaseStore.js so routes never need to know which one
// is active. Data does not persist across server restarts — that's
// expected; this exists so the whole app can be built and tested before
// real QuickBase credentials are available.

let nextId = 1;
const products = [];
const purchases = [];
const transactions = [];

function id() {
  return nextId++;
}

export async function listProducts({ search } = {}) {
  if (!search) return [...products];
  const q = search.toLowerCase();
  return products.filter(
    (p) =>
      p.name?.toLowerCase().includes(q) ||
      p.manufacturer?.toLowerCase().includes(q) ||
      p.barcode?.toLowerCase().includes(q) ||
      p.internalId?.toLowerCase().includes(q) ||
      p.category?.toLowerCase().includes(q)
  );
}

export async function getProductByBarcode(barcode) {
  return products.find((p) => p.barcode === barcode) || null;
}

// Renova-assigned ID lookup — lets someone type a tool's internal ID tag
// number and pull up everything already saved about it, same idea as
// barcode lookup but for tools that were catalogued under a self-issued ID
// rather than (or in addition to) a manufacturer barcode.
export async function getProductByInternalId(internalId) {
  return products.find((p) => p.internalId === internalId) || null;
}

export async function getProductById(productId) {
  return products.find((p) => p.id === Number(productId)) || null;
}

export async function createProduct(fields) {
  const product = { id: id(), ...fields };
  products.push(product);
  return product;
}

export async function updateProduct(productId, fields) {
  const idx = products.findIndex((p) => p.id === Number(productId));
  if (idx === -1) throw new Error('Product not found');
  products[idx] = { ...products[idx], ...fields };
  return products[idx];
}

export async function listPurchasesForProduct(productId) {
  return purchases.filter((p) => p.productId === Number(productId));
}

export async function createPurchase(fields) {
  const purchase = { id: id(), ...fields };
  purchases.push(purchase);
  return purchase;
}

export async function listTransactionsForProduct(productId) {
  return transactions.filter((t) => t.productId === Number(productId));
}

export async function createTransaction(fields) {
  const transaction = { id: id(), ...fields };
  transactions.push(transaction);
  return transaction;
}

// Exposed only for tests / seeding.
export function _reset() {
  nextId = 1;
  products.length = 0;
  purchases.length = 0;
  transactions.length = 0;
}
