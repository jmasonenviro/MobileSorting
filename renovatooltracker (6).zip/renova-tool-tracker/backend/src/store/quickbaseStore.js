// QuickBase-backed implementation of the same interface as mockStore.js.
// Field IDs are resolved dynamically at startup via getFields() rather than
// hardcoded, so this works against any app built by provision.js (or a
// hand-built app) as long as the field *labels* match schema.js.
//
// NOT smoke-tested against a live QuickBase account as of this build —
// there was no account available while writing it. Treat the first real
// run as a smoke test: check server logs on startup (field-map resolution
// happens then and will throw a clear error naming any missing field) and
// verify a single create/read round trip before relying on this in
// production.

import { config } from '../config.js';
import { queryRecords, upsertRecords, getFields } from '../quickbase/client.js';

const RECORD_ID_FIELD = 3; // QuickBase's built-in "Record ID#" field is always id 3.

// label -> camelCase key, per table. Keep in sync with schema.js labels.
const KEY_MAPS = {
  products: {
    Name: 'name',
    'Internal ID': 'internalId',
    Manufacturer: 'manufacturer',
    Barcode: 'barcode',
    Category: 'category',
    'Unit of Measure': 'unitOfMeasure',
    'Barcode Image': 'barcodeImage',
    Notes: 'notes',
  },
  purchases: {
    Product: 'productId',
    Vendor: 'vendor',
    'Purchase Date': 'purchaseDate',
    Quantity: 'quantity',
    'Unit Cost': 'unitCost',
    'Total Cost': 'totalCost',
    'PO Number': 'poNumber',
    Notes: 'notes',
  },
  transactions: {
    Product: 'productId',
    Type: 'type',
    Person: 'person',
    Quantity: 'quantity',
    'Job Site': 'jobSite',
    'Check-Out Date-Time': 'checkOutDateTime',
    'Expected Days': 'expectedDays',
    'Related Checkout': 'relatedCheckoutId',
    'Quantity Returned': 'quantityReturned',
    Condition: 'condition',
    'Check-In Date-Time': 'checkInDateTime',
    Notes: 'notes',
  },
};

const fieldIdCache = {}; // table key -> { label: fieldId }

async function fieldIds(tableKey) {
  if (fieldIdCache[tableKey]) return fieldIdCache[tableKey];

  const tableId = config.quickbase.tables[tableKey];
  if (!tableId) {
    throw new Error(
      `QB_TABLE_${tableKey.toUpperCase()} is not set. Run "npm run provision" or set it in .env.`
    );
  }

  const fields = await getFields(tableId);
  const map = { 'Record ID#': RECORD_ID_FIELD };
  for (const f of fields) map[f.label] = f.id;

  const missing = Object.keys(KEY_MAPS[tableKey]).filter((label) => !(label in map));
  if (missing.length) {
    throw new Error(
      `Table "${tableKey}" is missing expected field(s): ${missing.join(
        ', '
      )}. Re-run provisioning or add them manually in QuickBase.`
    );
  }

  fieldIdCache[tableKey] = map;
  return map;
}

function toObject(record, tableKey, ids) {
  const keyMap = KEY_MAPS[tableKey];
  const obj = { id: record[RECORD_ID_FIELD]?.value };
  for (const [label, key] of Object.entries(keyMap)) {
    const fid = ids[label];
    const raw = record[fid]?.value;
    obj[key] = key === 'barcodeImage' && raw ? raw : raw ?? null;
  }
  return obj;
}

async function toRecordData(obj, tableKey, ids) {
  const keyMap = KEY_MAPS[tableKey];
  const data = {};
  if (obj.id) data[RECORD_ID_FIELD] = { value: Number(obj.id) };
  for (const [label, key] of Object.entries(keyMap)) {
    if (!(key in obj)) continue;
    data[ids[label]] = { value: obj[key] };
  }
  return data;
}

async function insertOrUpdate(tableKey, obj) {
  const tableId = config.quickbase.tables[tableKey];
  const ids = await fieldIds(tableKey);
  const data = await toRecordData(obj, tableKey, ids);
  const res = await upsertRecords(tableId, [data]);
  const recordId = res?.metadata?.createdRecordIds?.[0] ?? obj.id;
  return { ...obj, id: recordId };
}

// ---- Products ----

export async function listProducts({ search } = {}) {
  const tableId = config.quickbase.tables.products;
  const ids = await fieldIds('products');
  let where;
  if (search) {
    const searchable = ['Name', 'Manufacturer', 'Barcode', 'Internal ID', 'Category'];
    where = searchable
      .map((label) => `{${ids[label]}.CT.'${search.replace(/'/g, "\\'")}'}`)
      .join('OR');
  }
  const res = await queryRecords({
    from: tableId,
    select: [RECORD_ID_FIELD, ...Object.values(ids).filter((v) => v !== RECORD_ID_FIELD)],
    where,
  });
  return (res.data || []).map((r) => toObject(r, 'products', ids));
}

export async function getProductByBarcode(barcode) {
  const ids = await fieldIds('products');
  const res = await queryRecords({
    from: config.quickbase.tables.products,
    select: [RECORD_ID_FIELD, ...Object.values(ids).filter((v) => v !== RECORD_ID_FIELD)],
    where: `{${ids.Barcode}.EX.'${barcode}'}`,
  });
  const [record] = res.data || [];
  return record ? toObject(record, 'products', ids) : null;
}

// Renova-assigned ID lookup — same idea as getProductByBarcode above, but
// keyed on the "Internal ID" field for tools catalogued under a self-issued
// Renova ID tag rather than (or in addition to) a manufacturer barcode.
export async function getProductByInternalId(internalId) {
  const ids = await fieldIds('products');
  const res = await queryRecords({
    from: config.quickbase.tables.products,
    select: [RECORD_ID_FIELD, ...Object.values(ids).filter((v) => v !== RECORD_ID_FIELD)],
    where: `{${ids['Internal ID']}.EX.'${internalId}'}`,
  });
  const [record] = res.data || [];
  return record ? toObject(record, 'products', ids) : null;
}

export async function getProductById(productId) {
  const ids = await fieldIds('products');
  const res = await queryRecords({
    from: config.quickbase.tables.products,
    select: [RECORD_ID_FIELD, ...Object.values(ids).filter((v) => v !== RECORD_ID_FIELD)],
    where: `{${RECORD_ID_FIELD}.EX.'${productId}'}`,
  });
  const [record] = res.data || [];
  return record ? toObject(record, 'products', ids) : null;
}

export async function createProduct(fields) {
  return insertOrUpdate('products', fields);
}

export async function updateProduct(productId, fields) {
  return insertOrUpdate('products', { ...fields, id: productId });
}

// ---- Purchases ----

export async function listPurchasesForProduct(productId) {
  const ids = await fieldIds('purchases');
  const res = await queryRecords({
    from: config.quickbase.tables.purchases,
    select: [RECORD_ID_FIELD, ...Object.values(ids).filter((v) => v !== RECORD_ID_FIELD)],
    where: `{${ids.Product}.EX.'${productId}'}`,
  });
  return (res.data || []).map((r) => toObject(r, 'purchases', ids));
}

export async function createPurchase(fields) {
  return insertOrUpdate('purchases', fields);
}

// ---- Transactions ----

export async function listTransactionsForProduct(productId) {
  const ids = await fieldIds('transactions');
  const res = await queryRecords({
    from: config.quickbase.tables.transactions,
    select: [RECORD_ID_FIELD, ...Object.values(ids).filter((v) => v !== RECORD_ID_FIELD)],
    where: `{${ids.Product}.EX.'${productId}'}`,
  });
  return (res.data || []).map((r) => toObject(r, 'transactions', ids));
}

export async function createTransaction(fields) {
  return insertOrUpdate('transactions', fields);
}
