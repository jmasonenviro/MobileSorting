import { isQuickBaseConfigured } from '../config.js';
import * as mockStore from './mockStore.js';
import * as quickbaseStore from './quickbaseStore.js';

const active = isQuickBaseConfigured() ? quickbaseStore : mockStore;

if (!isQuickBaseConfigured()) {
  console.log(
    '[store] QuickBase not configured — using in-memory mock data store. ' +
      'Set QB_REALM_HOSTNAME, QB_USER_TOKEN, QB_APP_ID (and QB_TABLE_* after ' +
      'running "npm run provision") in .env to switch to real QuickBase.'
  );
} else {
  console.log('[store] Using QuickBase as the data store.');
}

export default active;
