// Best-effort external product lookups. These are intentionally stubbed —
// no API keys were available at build time (by request; keys can be added
// later without changing the /lookup route's contract).
//
// Nothing in the app blocks on these: the Add Product form always works
// with manual entry regardless of what (if anything) comes back here.

import { config } from './config.js';

// GS1 GEPIR — resolves a barcode's GS1 company prefix to the registrant
// company name. Coverage is inconsistent and it often returns nothing for
// contractor/construction-tool manufacturers; treat any hit as a bonus.
// TODO: wire up a real GEPIR query once we've confirmed the integration
// approach (GEPIR doesn't have one single simple REST endpoint across all
// GS1 member organizations — this needs a short spike before implementing).
async function lookupGepir(barcode) {
  if (!config.lookups.gepirBaseUrl) {
    return { source: 'gepir', status: 'not_configured' };
  }
  // TODO: implement real GEPIR call.
  return { source: 'gepir', status: 'not_implemented' };
}

// Icecat — primary product-data source (name/brand/image) when available.
// TODO: add ICECAT_API_KEY to .env and implement the real call.
async function lookupIcecat(barcode) {
  if (!config.lookups.icecatApiKey) {
    return { source: 'icecat', status: 'not_configured' };
  }
  return { source: 'icecat', status: 'not_implemented' };
}

// UPCitemdb — backup product-data source.
// TODO: add UPCITEMDB_API_KEY to .env and implement the real call.
async function lookupUpcItemDb(barcode) {
  if (!config.lookups.upcItemDbApiKey) {
    return { source: 'upcitemdb', status: 'not_configured' };
  }
  return { source: 'upcitemdb', status: 'not_implemented' };
}

// Go-UPC — second backup product-data source.
// TODO: add GO_UPC_API_KEY to .env and implement the real call.
async function lookupGoUpc(barcode) {
  if (!config.lookups.goUpcApiKey) {
    return { source: 'go-upc', status: 'not_configured' };
  }
  return { source: 'go-upc', status: 'not_implemented' };
}

/**
 * Runs all lookups (in priority order) and merges whatever comes back into
 * a single best-effort pre-fill object. Never throws — a failed/unconfigured
 * lookup just contributes nothing.
 */
export async function runLookups(barcode) {
  const results = await Promise.allSettled([
    lookupGepir(barcode),
    lookupIcecat(barcode),
    lookupUpcItemDb(barcode),
    lookupGoUpc(barcode),
  ]);

  const sources = results.map((r) =>
    r.status === 'fulfilled' ? r.value : { status: 'error', error: String(r.reason) }
  );

  const prefill = {
    manufacturer: sources.find((s) => s.manufacturer)?.manufacturer ?? null,
    name: sources.find((s) => s.name)?.name ?? null,
    brand: sources.find((s) => s.brand)?.brand ?? null,
    imageUrl: sources.find((s) => s.imageUrl)?.imageUrl ?? null,
  };

  return { barcode, prefill, sources };
}
